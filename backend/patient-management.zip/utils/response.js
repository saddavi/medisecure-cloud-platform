"use strict";
// MediSecure Cloud Platform - Response Utilities
// Standardized API responses for consistency and debugging
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogLevel = void 0;
exports.createResponse = createResponse;
exports.successResponse = successResponse;
exports.createdResponse = createdResponse;
exports.badRequestResponse = badRequestResponse;
exports.unauthorizedResponse = unauthorizedResponse;
exports.forbiddenResponse = forbiddenResponse;
exports.notFoundResponse = notFoundResponse;
exports.conflictResponse = conflictResponse;
exports.tooManyRequestsResponse = tooManyRequestsResponse;
exports.internalServerErrorResponse = internalServerErrorResponse;
exports.handleMediSecureError = handleMediSecureError;
exports.log = log;
exports.parseRequestBody = parseRequestBody;
exports.getEnvVar = getEnvVar;
exports.validateEnvironment = validateEnvironment;
exports.validateRequest = validateRequest;
const types_1 = require("../types");
const uuid_1 = require("uuid");
// ============= Response Builder =============
/**
 * Creates a standardized API response
 * @param statusCode - HTTP status code
 * @param success - Whether the operation was successful
 * @param message - Human-readable message
 * @param data - Optional response data
 * @param error - Optional error details
 * @returns APIGatewayProxyResult formatted response
 */
function createResponse(statusCode, success, message, data, error) {
    const response = {
        statusCode,
        success,
        message,
        timestamp: new Date().toISOString(),
        requestId: (0, uuid_1.v4)(),
    };
    if (data !== undefined) {
        response.data = data;
    }
    if (error) {
        response.error = error;
    }
    return {
        statusCode,
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*", // Configure this properly for production
            "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE",
        },
        body: JSON.stringify(response),
    };
}
// ============= Success Responses =============
function successResponse(data, message = "Success") {
    return createResponse(200, true, message, data);
}
function createdResponse(data, message = "Resource created successfully") {
    return createResponse(201, true, message, data);
}
// ============= Error Responses =============
function badRequestResponse(message = "Bad Request", errors) {
    return createResponse(400, false, message, undefined, errors?.join(", "));
}
function unauthorizedResponse(message = "Unauthorized") {
    return createResponse(401, false, message);
}
function forbiddenResponse(message = "Forbidden") {
    return createResponse(403, false, message);
}
function notFoundResponse(message = "Resource not found") {
    return createResponse(404, false, message);
}
function conflictResponse(message = "Resource already exists") {
    return createResponse(409, false, message);
}
function tooManyRequestsResponse(message = "Too many requests") {
    return createResponse(429, false, message);
}
function internalServerErrorResponse(message = "Internal server error", error) {
    return createResponse(500, false, message, undefined, error);
}
// ============= MediSecure Error Handler =============
/**
 * Handles MediSecure-specific errors and converts them to appropriate HTTP responses
 * @param error - MediSecure error object
 * @returns APIGatewayProxyResult
 */
function handleMediSecureError(error) {
    switch (error.code) {
        case types_1.ErrorCodes.VALIDATION_ERROR:
            return badRequestResponse(error.message, error.details);
        case types_1.ErrorCodes.AUTHENTICATION_ERROR:
        case types_1.ErrorCodes.INVALID_CREDENTIALS:
            return unauthorizedResponse(error.message);
        case types_1.ErrorCodes.AUTHORIZATION_ERROR:
            return forbiddenResponse(error.message);
        case types_1.ErrorCodes.USER_EXISTS:
            return conflictResponse(error.message);
        case types_1.ErrorCodes.USER_NOT_FOUND:
            return notFoundResponse(error.message);
        case types_1.ErrorCodes.EMAIL_NOT_VERIFIED:
            return badRequestResponse(error.message);
        case types_1.ErrorCodes.RATE_LIMIT_EXCEEDED:
            return tooManyRequestsResponse(error.message);
        case types_1.ErrorCodes.INTERNAL_ERROR:
        default:
            return internalServerErrorResponse(error.message);
    }
}
// ============= Logger =============
var LogLevel;
(function (LogLevel) {
    LogLevel["DEBUG"] = "debug";
    LogLevel["INFO"] = "info";
    LogLevel["WARN"] = "warn";
    LogLevel["ERROR"] = "error";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
/**
 * Structured logging for Lambda functions
 * @param level - Log level
 * @param message - Log message
 * @param data - Optional structured data
 */
function log(level, message, data) {
    const logEntry = {
        timestamp: new Date().toISOString(),
        level,
        message,
        service: "medisecure-backend",
        ...(data && { data }),
    };
    console.log(JSON.stringify(logEntry));
}
// ============= Request Parser =============
/**
 * Safely parses JSON from Lambda event body
 * @param body - Request body string
 * @returns Parsed object or null if invalid
 */
function parseRequestBody(body) {
    if (!body) {
        return null;
    }
    try {
        return JSON.parse(body);
    }
    catch (error) {
        log(LogLevel.WARN, "Failed to parse request body", {
            body,
            error: error instanceof Error ? error.message : "Unknown error",
        });
        return null;
    }
}
// ============= Environment Configuration =============
/**
 * Gets environment variable with fallback
 * @param key - Environment variable key
 * @param fallback - Fallback value if not found
 * @returns Environment variable value or fallback
 */
function getEnvVar(key, fallback) {
    const value = process.env[key];
    if (!value) {
        if (fallback !== undefined) {
            return fallback;
        }
        throw new Error(`Environment variable ${key} is required but not set`);
    }
    return value;
}
/**
 * Validates that all required environment variables are set
 * @param requiredVars - Array of required environment variable names
 * @throws Error if any required variable is missing
 */
function validateEnvironment(requiredVars) {
    const missing = requiredVars.filter((varName) => !process.env[varName]);
    if (missing.length > 0) {
        throw new Error(`Missing required environment variables: ${missing.join(", ")}`);
    }
}
/**
 * Validates API Gateway request structure
 * @param event - API Gateway event
 * @param requiredFields - Array of required fields in the request body
 * @returns Parsed request body or throws validation error
 */
function validateRequest(event, requiredFields = []) {
    // Validate HTTP method
    if (!event.httpMethod) {
        throw new Error("HTTP method is required");
    }
    // For GET requests, return path parameters
    if (event.httpMethod === "GET") {
        return (event.pathParameters || {});
    }
    // For POST/PUT requests, validate body
    if (!event.body) {
        throw new Error("Request body is required");
    }
    let requestData;
    try {
        requestData = JSON.parse(event.body);
    }
    catch (error) {
        throw new Error("Invalid JSON in request body");
    }
    // Validate required fields
    const missingFields = requiredFields.filter((field) => !requestData[field]);
    if (missingFields.length > 0) {
        throw new Error(`Missing required fields: ${missingFields.join(", ")}`);
    }
    return requestData;
}
