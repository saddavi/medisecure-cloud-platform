import { APIGatewayProxyEvent } from "aws-lambda";
export interface QatarHealthcareAuditContext {
    healthcareProviderId: string;
    facilityId: string;
    patientQatarId?: string;
    dataClassification: "PUBLIC" | "INTERNAL" | "CONFIDENTIAL" | "RESTRICTED";
    regulatoryFramework: "QNHS" | "GCC_HEALTH" | "HIPAA_EQUIVALENT";
    sessionId: string;
    geolocation?: {
        region: "QATAR" | "GCC" | "INTERNATIONAL";
        accessLocation: string;
    };
}
export declare class QatarHealthcareAuditService {
    private auditLogger;
    constructor();
    auditPatientDataAccess(event: APIGatewayProxyEvent, patientId: string, accessType: "VIEW" | "EDIT" | "EXPORT", qatarContext: QatarHealthcareAuditContext): Promise<void>;
    auditMedicalRecordOperation(event: APIGatewayProxyEvent, operation: "CREATE" | "UPDATE" | "DELETE" | "SHARE", recordId: string, qatarContext: QatarHealthcareAuditContext, changeDetails?: any): Promise<void>;
    auditSecurityEvent(event: APIGatewayProxyEvent, securityEventType: "UNAUTHORIZED_ACCESS" | "SUSPICIOUS_PATTERN" | "DATA_BREACH_ATTEMPT", severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL", qatarContext: QatarHealthcareAuditContext): Promise<void>;
    private mapAccessTypeToAuditAction;
    private mapOperationToAuditAction;
    private extractUserFromJWT;
    private analyzeAccessPattern;
    private calculateRiskScore;
    private calculateRetentionPeriod;
    private inferBusinessJustification;
    private analyzeRequestPattern;
    private assessBusinessImpact;
    private generateIncidentId;
    private notifySecurityTeam;
}
export declare const qatarAuditService: QatarHealthcareAuditService;
