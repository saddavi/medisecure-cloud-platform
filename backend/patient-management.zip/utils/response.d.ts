import { APIGatewayProxyResult } from "aws-lambda";
import { MediSecureError } from "../types";
/**
 * Creates a standardized API response
 * @param statusCode - HTTP status code
 * @param success - Whether the operation was successful
 * @param message - Human-readable message
 * @param data - Optional response data
 * @param error - Optional error details
 * @returns APIGatewayProxyResult formatted response
 */
export declare function createResponse<T = any>(statusCode: number, success: boolean, message: string, data?: T, error?: string): APIGatewayProxyResult;
export declare function successResponse<T = any>(data?: T, message?: string): APIGatewayProxyResult;
export declare function createdResponse<T = any>(data?: T, message?: string): APIGatewayProxyResult;
export declare function badRequestResponse(message?: string, errors?: string[]): APIGatewayProxyResult;
export declare function unauthorizedResponse(message?: string): APIGatewayProxyResult;
export declare function forbiddenResponse(message?: string): APIGatewayProxyResult;
export declare function notFoundResponse(message?: string): APIGatewayProxyResult;
export declare function conflictResponse(message?: string): APIGatewayProxyResult;
export declare function tooManyRequestsResponse(message?: string): APIGatewayProxyResult;
export declare function internalServerErrorResponse(message?: string, error?: string): APIGatewayProxyResult;
/**
 * Handles MediSecure-specific errors and converts them to appropriate HTTP responses
 * @param error - MediSecure error object
 * @returns APIGatewayProxyResult
 */
export declare function handleMediSecureError(error: MediSecureError): APIGatewayProxyResult;
export declare enum LogLevel {
    DEBUG = "debug",
    INFO = "info",
    WARN = "warn",
    ERROR = "error"
}
/**
 * Structured logging for Lambda functions
 * @param level - Log level
 * @param message - Log message
 * @param data - Optional structured data
 */
export declare function log(level: LogLevel, message: string, data?: any): void;
/**
 * Safely parses JSON from Lambda event body
 * @param body - Request body string
 * @returns Parsed object or null if invalid
 */
export declare function parseRequestBody<T = any>(body: string | null): T | null;
/**
 * Gets environment variable with fallback
 * @param key - Environment variable key
 * @param fallback - Fallback value if not found
 * @returns Environment variable value or fallback
 */
export declare function getEnvVar(key: string, fallback?: string): string;
/**
 * Validates that all required environment variables are set
 * @param requiredVars - Array of required environment variable names
 * @throws Error if any required variable is missing
 */
export declare function validateEnvironment(requiredVars: string[]): void;
/**
 * Validates API Gateway request structure
 * @param event - API Gateway event
 * @param requiredFields - Array of required fields in the request body
 * @returns Parsed request body or throws validation error
 */
export declare function validateRequest<T = any>(event: {
    body?: string | null;
    httpMethod?: string;
    pathParameters?: any;
}, requiredFields?: string[]): T;
