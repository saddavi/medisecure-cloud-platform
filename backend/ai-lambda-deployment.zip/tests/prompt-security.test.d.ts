/**
 * Prompt Security Tests
 * Tests prompt injection protection for AI symptom checker
 */
export declare function runPromptSecurityDemo(): void;
