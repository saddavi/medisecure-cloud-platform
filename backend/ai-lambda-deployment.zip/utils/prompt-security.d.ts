/**
 * Prompt Security Utility for AI Symptom Checker
 * Prevents prompt injection attacks while preserving medical terminology
 */
export declare class PromptSecurity {
    /**
     * Sanitize user input to prevent prompt injection attacks
     * Focused on common attack patterns without over-engineering
     */
    static sanitizeSymptoms(input: string): string;
    /**
     * Check if input contains potential malicious patterns
     * Returns true if suspicious content detected
     */
    static detectMaliciousIntent(input: string): boolean;
    /**
     * Create a safe prompt structure with delimiters
     * This prevents the AI from treating user input as instructions
     */
    static wrapWithDelimiters(userInput: string): string;
}
