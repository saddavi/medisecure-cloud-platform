/**
 * DynamoDB Service for MediSecure Cloud Platform
 * Handles all database operations with proper error handling
 */
export declare class DynamoDBService {
    private docClient;
    private tableName;
    constructor();
    /**
     * Put item into DynamoDB
     */
    putItem(item: any): Promise<void>;
    /**
     * Get item from DynamoDB
     */
    getItem(pk: string, sk: string): Promise<any>;
    /**
     * Query items from DynamoDB
     */
    queryItems(pk: string, options?: {
        limit?: number;
        startKey?: any;
        sortKeyCondition?: string;
    }): Promise<{
        items: any[];
        lastEvaluatedKey?: any;
    }>;
    /**
     * Update item in DynamoDB
     */
    updateItem(pk: string, sk: string, updates: any): Promise<void>;
}
