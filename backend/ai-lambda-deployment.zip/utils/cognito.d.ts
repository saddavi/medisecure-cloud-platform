import { UserRegistrationRequest, UserRegistrationResponse, UserLoginRequest, UserLoginResponse } from "../types";
export declare class CognitoService {
    private client;
    private config;
    constructor();
    /**
     * Generates SECRET_HASH required for Cognito operations when client secret is used
     * @param username - The username (email in our case)
     * @returns The computed SECRET_HASH
     */
    private generateSecretHash;
    /**
     * Registers a new user in Cognito User Pool
     * @param userData - User registration data
     * @returns Promise<UserRegistrationResponse>
     */
    registerUser(userData: UserRegistrationRequest): Promise<UserRegistrationResponse>;
    /**
     * Authenticates a user with email and password
     * @param loginData - User login credentials
     * @returns Promise<UserLoginResponse>
     */
    authenticateUser(loginData: UserLoginRequest): Promise<UserLoginResponse>;
    /**
     * Confirms user email with verification code
     * @param email - User email
     * @param confirmationCode - Verification code
     * @returns Promise<boolean>
     */
    confirmEmailVerification(email: string, confirmationCode: string): Promise<boolean>;
    /**
     * Resends email verification code
     * @param email - User email
     * @returns Promise<boolean>
     */
    resendVerificationCode(email: string): Promise<boolean>;
    /**
     * Initiates password reset process
     * @param email - User email
     * @returns Promise<boolean>
     */
    initiatePasswordReset(email: string): Promise<boolean>;
    /**
     * Confirms password reset with verification code
     * @param email - User email
     * @param confirmationCode - Verification code
     * @param newPassword - New password
     * @returns Promise<boolean>
     */
    confirmPasswordReset(email: string, confirmationCode: string, newPassword: string): Promise<boolean>;
    private handleCognitoError;
    private handleAuthError;
    private getChallengeMessage;
}
