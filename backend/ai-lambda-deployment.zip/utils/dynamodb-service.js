"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBService = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
/**
 * DynamoDB Service for MediSecure Cloud Platform
 * Handles all database operations with proper error handling
 */
class DynamoDBService {
    constructor() {
        const client = new client_dynamodb_1.DynamoDBClient({
            region: process.env.AWS_REGION || "me-south-1",
        });
        this.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
        this.tableName = process.env.DYNAMODB_TABLE_NAME || "MediSecure-HealthData";
    }
    /**
     * Put item into DynamoDB
     */
    async putItem(item) {
        try {
            await this.docClient.send(new lib_dynamodb_1.PutCommand({
                TableName: this.tableName,
                Item: item,
            }));
        }
        catch (error) {
            console.error("DynamoDB put error:", error);
            throw new Error("Failed to save data");
        }
    }
    /**
     * Get item from DynamoDB
     */
    async getItem(pk, sk) {
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.GetCommand({
                TableName: this.tableName,
                Key: { PK: pk, SK: sk },
            }));
            return result.Item;
        }
        catch (error) {
            console.error("DynamoDB get error:", error);
            throw new Error("Failed to retrieve data");
        }
    }
    /**
     * Query items from DynamoDB
     */
    async queryItems(pk, options) {
        try {
            const result = await this.docClient.send(new lib_dynamodb_1.QueryCommand({
                TableName: this.tableName,
                KeyConditionExpression: "PK = :pk",
                ExpressionAttributeValues: { ":pk": pk },
                Limit: options?.limit,
                ExclusiveStartKey: options?.startKey,
            }));
            return {
                items: result.Items || [],
                lastEvaluatedKey: result.LastEvaluatedKey,
            };
        }
        catch (error) {
            console.error("DynamoDB query error:", error);
            throw new Error("Failed to query data");
        }
    }
    /**
     * Update item in DynamoDB
     */
    async updateItem(pk, sk, updates) {
        try {
            const updateExpression = "SET " +
                Object.keys(updates)
                    .map((key) => `#${key} = :${key}`)
                    .join(", ");
            const expressionAttributeNames = Object.keys(updates).reduce((acc, key) => {
                acc[`#${key}`] = key;
                return acc;
            }, {});
            const expressionAttributeValues = Object.keys(updates).reduce((acc, key) => {
                acc[`:${key}`] = updates[key];
                return acc;
            }, {});
            await this.docClient.send(new lib_dynamodb_1.UpdateCommand({
                TableName: this.tableName,
                Key: { PK: pk, SK: sk },
                UpdateExpression: updateExpression,
                ExpressionAttributeNames: expressionAttributeNames,
                ExpressionAttributeValues: expressionAttributeValues,
            }));
        }
        catch (error) {
            console.error("DynamoDB update error:", error);
            throw new Error("Failed to update data");
        }
    }
}
exports.DynamoDBService = DynamoDBService;
