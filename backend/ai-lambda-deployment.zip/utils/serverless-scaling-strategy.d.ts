export interface HealthcareWorkloadPattern {
    businessHours: boolean;
    emergencyHours: boolean;
    weekendMode: boolean;
    patientLoad: "LOW" | "NORMAL" | "HIGH" | "EMERGENCY";
    concurrentProviders: number;
    dataVolumeGB: number;
    ramadanSchedule?: boolean;
    pilgrimeageSeason?: boolean;
    gccCrossRegionTraffic: boolean;
}
export interface ScalingMetrics {
    lambdaColdStarts: number;
    apiGatewayLatency: number;
    dynamodbThrottling: number;
    costPerPatientRecord: number;
    revenuePerApiCall: number;
    patientSatisfactionScore: number;
    auditLogLatency: number;
    dataRetentionCost: number;
    regulatoryComplianceScore: number;
}
export declare class ServerlessScalingOptimizer {
    private cloudWatch;
    private lambda;
    constructor();
    optimizeForHealthcareWorkload(workloadPattern: HealthcareWorkloadPattern, currentMetrics: ScalingMetrics): Promise<{
        recommendedConfig: any;
        costImpact: string;
        businessJustification: string;
    }>;
    handleEmergencyScaling(emergencyType: "PANDEMIC" | "NATURAL_DISASTER" | "CYBER_ATTACK" | "SYSTEM_OVERLOAD", expectedLoadMultiplier: number): Promise<void>;
    optimizeForCostEfficiency(budgetConstraint: number, performanceRequirements: {
        maxLatency: number;
        minAvailability: number;
        maxColdStarts: number;
    }): Promise<{
        configuration: any;
        estimatedMonthlyCost: number;
        performanceTradeoffs: string[];
    }>;
    optimizeForQatarMarket(): Promise<{
        regionalStrategy: any;
        complianceOptimizations: string[];
        marketDifferentiators: string[];
    }>;
    private determineScalingStrategy;
    private calculateOptimalConfiguration;
    private calculateEmergencyConcurrency;
    private estimateMonthlyCost;
    private identifyPerformanceTradeoffs;
    private analyzeCostImpact;
    private generateBusinessJustification;
    private applyEmergencyConfiguration;
    private notifyEmergencyScaling;
    publishHealthcareMetrics(metrics: ScalingMetrics): Promise<void>;
}
export declare const scalingOptimizer: ServerlessScalingOptimizer;
