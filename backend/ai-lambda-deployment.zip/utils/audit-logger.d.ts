import { APIGatewayProxyEvent } from "aws-lambda";
export declare enum AuditAction {
    USER_LOGIN = "USER_LOGIN",
    USER_LOGOUT = "USER_LOGOUT",
    USER_REGISTRATION = "USER_REGISTRATION",
    PASSWORD_RESET = "PASSWORD_RESET",
    PATIENT_PROFILE_VIEW = "PATIENT_PROFILE_VIEW",
    PATIENT_PROFILE_UPDATE = "PATIENT_PROFILE_UPDATE",
    MEDICAL_RECORD_VIEW = "MEDICAL_RECORD_VIEW",
    MEDICAL_RECORD_CREATE = "MEDICAL_RECORD_CREATE",
    MEDICAL_RECORD_UPDATE = "MEDICAL_RECORD_UPDATE",
    MEDICAL_RECORD_DELETE = "MEDICAL_RECORD_DELETE",
    USER_ROLE_CHANGE = "USER_ROLE_CHANGE",
    SYSTEM_CONFIGURATION = "SYSTEM_CONFIGURATION",
    EXPORT_PATIENT_DATA = "EXPORT_PATIENT_DATA",
    UNAUTHORIZED_ACCESS = "UNAUTHORIZED_ACCESS",
    FAILED_LOGIN = "FAILED_LOGIN",
    SUSPICIOUS_ACTIVITY = "SUSPICIOUS_ACTIVITY"
}
export declare enum AuditResult {
    SUCCESS = "SUCCESS",
    FAILURE = "FAILURE",
    UNAUTHORIZED = "UNAUTHORIZED",
    ERROR = "ERROR"
}
export interface AuditEvent {
    action: AuditAction;
    result: AuditResult;
    timestamp: string;
    userId?: string;
    userEmail?: string;
    userRole?: string;
    cognitoUserId?: string;
    resourceType?: string;
    resourceId?: string;
    patientId?: string;
    ipAddress?: string;
    userAgent?: string;
    requestId?: string;
    sessionId?: string;
    location?: string;
    facilityId?: string;
    authMethod?: string;
    errorCode?: string;
    errorMessage?: string;
    oldData?: any;
    newData?: any;
    dataClassification?: "PUBLIC" | "CONFIDENTIAL" | "RESTRICTED" | "MEDICAL";
    retentionPeriod?: string;
}
export declare class HealthcareAuditLogger {
    private dynamoClient;
    private tableName;
    constructor();
    /**
     * Log an audit event with healthcare compliance standards
     * @param event Audit event to log
     * @param apiEvent Optional API Gateway event for automatic context extraction
     */
    logAuditEvent(event: Partial<AuditEvent>, apiEvent?: APIGatewayProxyEvent): Promise<void>;
    /**
     * Extract context information from API Gateway event
     */
    private extractContextFromApiEvent;
    /**
     * Calculate TTL timestamp for automatic record cleanup
     */
    private calculateTTL;
    /**
     * Qatar-specific convenience methods for common audit scenarios
     */
    /**
     * Log patient data access (Qatar healthcare regulation requirement)
     */
    logPatientDataAccess(patientId: string, userId: string, action: AuditAction, apiEvent?: APIGatewayProxyEvent): Promise<void>;
    /**
     * Log authentication events for security monitoring
     */
    logAuthEvent(action: AuditAction, userId: string, result: AuditResult, errorCode?: string, apiEvent?: APIGatewayProxyEvent): Promise<void>;
    /**
     * Log administrative actions for compliance
     */
    logAdminAction(action: AuditAction, adminUserId: string, targetResourceId: string, oldData?: any, newData?: any, apiEvent?: APIGatewayProxyEvent): Promise<void>;
}
export declare const auditLogger: HealthcareAuditLogger;
/**
 * Quick audit logging for Lambda functions
 */
export declare const logAudit: (action: AuditAction, userId: string, details?: Partial<AuditEvent>) => Promise<void>;
/**
 * Log failed operations for security monitoring
 */
export declare const logAuditFailure: (action: AuditAction, userId: string, errorCode: string, errorMessage: string, details?: Partial<AuditEvent>) => Promise<void>;
