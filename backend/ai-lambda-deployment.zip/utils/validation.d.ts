import { ValidationResult } from "../types";
/**
 * Validates user registration data
 * @param data - User registration request data
 * @returns ValidationResult with success status and any errors
 */
export declare function validateRegistration(data: any): ValidationResult;
/**
 * Validates user login data
 * @param data - User login request data
 * @returns ValidationResult with success status and any errors
 */
export declare function validateLogin(data: any): ValidationResult;
/**
 * Sanitizes user input to prevent XSS and injection attacks
 * @param input - String input to sanitize
 * @returns Sanitized string
 */
export declare function sanitizeInput(input: string): string;
/**
 * Validates Qatar-specific data formats
 * @param data - Data to validate
 * @returns ValidationResult
 */
export declare function validateQatarSpecific(data: any): ValidationResult;
