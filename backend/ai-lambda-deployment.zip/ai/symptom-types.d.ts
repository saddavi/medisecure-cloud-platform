/**
 * TypeScript interfaces and types for AI-powered symptom analysis
 * MediSecure Cloud Platform - Qatar Healthcare System
 */
export interface SymptomInput {
    description: string;
    severity?: number;
    duration?: string;
    location?: string;
    triggers?: string[];
    associatedSymptoms?: string[];
    language: "en" | "ar";
}
export interface PatientContext {
    sessionId?: string;
    patientId?: string;
    age?: number;
    gender?: "male" | "female";
    medicalHistory?: MedicalCondition[];
    medications?: Medication[];
    allergies?: string[];
    culturalPreferences?: CulturalPreferences;
    emergencyContact?: EmergencyContact;
}
export interface MedicalCondition {
    condition: string;
    diagnosedDate?: string;
    severity: "mild" | "moderate" | "severe";
    isActive: boolean;
}
export interface Medication {
    name: string;
    dosage: string;
    frequency: string;
    startDate: string;
    isActive: boolean;
}
export interface CulturalPreferences {
    preferredLanguage: "en" | "ar";
    religiousConsiderations?: string[];
    dietaryRestrictions?: string[];
    genderPreferenceForProvider?: "male" | "female" | "no-preference";
}
export interface EmergencyContact {
    name: string;
    relationship: string;
    phoneNumber: string;
    isEmergencyService?: boolean;
}
export interface AISymptomAnalysis {
    analysis: string;
    severity: SymptomSeverity;
    urgencyScore: number;
    recommendations: HealthRecommendations;
    followUpQuestions: string[];
    culturalConsiderations?: string[];
    emergencyWarning?: string;
    confidenceScore: number;
    language: "en" | "ar";
    timestamp: string;
    sessionId: string;
}
export type SymptomSeverity = "Low" | "Medium" | "High" | "Emergency";
export interface HealthRecommendations {
    action: RecommendedAction;
    timeframe: string;
    specialist?: MedicalSpecialty;
    selfCareInstructions?: string[];
    medications?: OverTheCounterRecommendation[];
    lifestyle?: LifestyleRecommendation[];
    redFlags?: string[];
}
export type RecommendedAction = "self-care" | "appointment" | "urgent-care" | "emergency" | "telemedicine" | "specialist-referral";
export type MedicalSpecialty = "family-medicine" | "internal-medicine" | "cardiology" | "dermatology" | "orthopedics" | "neurology" | "psychiatry" | "pediatrics" | "gynecology" | "emergency-medicine" | "gastroenterology" | "pulmonology" | "endocrinology" | "ophthalmology" | "ent" | "urology";
export interface OverTheCounterRecommendation {
    medication: string;
    dosage: string;
    duration: string;
    warnings?: string[];
    islamicCompliance?: boolean;
}
export interface LifestyleRecommendation {
    category: "diet" | "exercise" | "sleep" | "stress" | "hydration" | "other";
    recommendation: string;
    culturalAdaptation?: string;
}
export interface AnonymousSession {
    sessionId: string;
    symptoms: SymptomInput[];
    aiAnalysis?: AISymptomAnalysis;
    language: "en" | "ar";
    createdAt: Date;
    expiresAt: Date;
    ipAddress?: string;
    userAgent?: string;
    convertedToPatient?: boolean;
}
export interface AnonymousSymptomResponse {
    analysis: string;
    severity: SymptomSeverity;
    urgencyScore: number;
    recommendations: {
        action: RecommendedAction;
        timeframe: string;
    };
    generalAdvice: string;
    whenToSeekHelp: string;
    registrationPrompt: string;
    sessionId: string;
    language: "en" | "ar";
    emergencyWarning?: string;
}
export interface QatarHealthcareProvider {
    name: string;
    type: "hospital" | "clinic" | "emergency" | "specialist";
    location: QatarLocation;
    services: MedicalSpecialty[];
    emergencyCapable: boolean;
    acceptsInsurance: string[];
    contactInfo: {
        phone: string;
        address: string;
        website?: string;
    };
    languages: ("en" | "ar")[];
}
export type QatarLocation = "doha-city" | "west-bay" | "al-rayyan" | "al-wakrah" | "al-khor" | "dukhan" | "mesaieed" | "other";
export interface EmergencyAssessment {
    isEmergency: boolean;
    urgencyLevel: "Critical" | "High" | "Medium" | "Low";
    immediateActions: string[];
    emergencyContacts: QatarEmergencyContact[];
    transportAdvice: string;
    language: "en" | "ar";
}
export interface QatarEmergencyContact {
    name: string;
    number: string;
    type: "ambulance" | "police" | "fire" | "poison-control" | "hospital";
    description: string;
    language: "en" | "ar" | "both";
}
export interface SymptomAnalysisRecord {
    PK: string;
    SK: string;
    GSI1PK?: string;
    GSI1SK?: string;
    symptoms: SymptomInput[];
    aiAnalysis: AISymptomAnalysis;
    patientContext?: PatientContext;
    isAnonymous: boolean;
    createdAt: string;
    updatedAt: string;
    ttl?: number;
    location?: QatarLocation;
    culturalContext?: "qatar" | "gulf" | "general";
}
export interface AnalyzeSymptomRequest {
    symptoms: SymptomInput;
    patientContext?: Partial<PatientContext>;
    isAnonymous?: boolean;
    language: "en" | "ar";
}
export interface AnalyzeSymptomResponse {
    success: boolean;
    data?: AISymptomAnalysis | AnonymousSymptomResponse;
    error?: {
        code: string;
        message: string;
        details?: any;
    };
    sessionId: string;
    rateLimit?: {
        remaining: number;
        resetTime: Date;
    };
}
export interface GetSymptomHistoryRequest {
    patientId?: string;
    sessionId?: string;
    limit?: number;
    startDate?: string;
    endDate?: string;
}
export interface GetSymptomHistoryResponse {
    success: boolean;
    data?: SymptomAnalysisRecord[];
    pagination?: {
        hasMore: boolean;
        nextToken?: string;
    };
    error?: {
        code: string;
        message: string;
    };
}
export interface AIModelConfig {
    modelId: string;
    maxTokens: number;
    temperature: number;
    region: string;
    costPerToken: number;
}
export interface RateLimitConfig {
    maxRequestsPerHour: number;
    maxRequestsPerDay: number;
    maxTokensPerHour: number;
    anonymousLimits: {
        maxRequestsPerHour: number;
        maxRequestsPerIP: number;
    };
}
export declare const SUPPORTED_LANGUAGES: readonly ["en", "ar"];
export declare const SYMPTOM_SEVERITIES: readonly ["Low", "Medium", "High", "Emergency"];
export declare const RECOMMENDED_ACTIONS: readonly ["self-care", "appointment", "urgent-care", "emergency", "telemedicine", "specialist-referral"];
export declare const QATAR_LOCATIONS: readonly ["doha-city", "west-bay", "al-rayyan", "al-wakrah", "al-khor", "dukhan", "mesaieed", "other"];
export declare const QATAR_EMERGENCY_CONTACTS: QatarEmergencyContact[];
export declare const AI_MODEL_CONFIGS: Record<string, AIModelConfig>;
declare const _default: {
    SUPPORTED_LANGUAGES: readonly ["en", "ar"];
    SYMPTOM_SEVERITIES: readonly ["Low", "Medium", "High", "Emergency"];
    RECOMMENDED_ACTIONS: readonly ["self-care", "appointment", "urgent-care", "emergency", "telemedicine", "specialist-referral"];
    QATAR_LOCATIONS: readonly ["doha-city", "west-bay", "al-rayyan", "al-wakrah", "al-khor", "dukhan", "mesaieed", "other"];
    QATAR_EMERGENCY_CONTACTS: QatarEmergencyContact[];
    AI_MODEL_CONFIGS: Record<string, AIModelConfig>;
};
export default _default;
