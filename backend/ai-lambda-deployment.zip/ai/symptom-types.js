"use strict";
/**
 * TypeScript interfaces and types for AI-powered symptom analysis
 * MediSecure Cloud Platform - Qatar Healthcare System
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AI_MODEL_CONFIGS = exports.QATAR_EMERGENCY_CONTACTS = exports.QATAR_LOCATIONS = exports.RECOMMENDED_ACTIONS = exports.SYMPTOM_SEVERITIES = exports.SUPPORTED_LANGUAGES = void 0;
// ============= Validation Schemas =============
exports.SUPPORTED_LANGUAGES = ["en", "ar"];
exports.SYMPTOM_SEVERITIES = [
    "Low",
    "Medium",
    "High",
    "Emergency",
];
exports.RECOMMENDED_ACTIONS = [
    "self-care",
    "appointment",
    "urgent-care",
    "emergency",
    "telemedicine",
    "specialist-referral",
];
exports.QATAR_LOCATIONS = [
    "doha-city",
    "west-bay",
    "al-rayyan",
    "al-wakrah",
    "al-khor",
    "dukhan",
    "mesaieed",
    "other",
];
// ============= Constants =============
exports.QATAR_EMERGENCY_CONTACTS = [
    {
        name: "Emergency Services",
        number: "999",
        type: "ambulance",
        description: "All emergency services",
        language: "both",
    },
    {
        name: "Hamad Medical Corporation",
        number: "+974 4439 4444",
        type: "hospital",
        description: "Main public hospital system",
        language: "both",
    },
    {
        name: "Qatar Red Crescent",
        number: "+974 4442 2222",
        type: "ambulance",
        description: "Emergency medical services",
        language: "both",
    },
    {
        name: "Poison Control",
        number: "+974 4439 9999",
        type: "poison-control",
        description: "Poison control and drug information",
        language: "both",
    },
];
exports.AI_MODEL_CONFIGS = {
    "claude-3-haiku": {
        modelId: "anthropic.claude-3-haiku-20240307-v1:0",
        maxTokens: 1000,
        temperature: 0.3,
        region: "us-east-1",
        costPerToken: 0.00025, // USD per 1K tokens
    },
    "claude-3-sonnet": {
        modelId: "anthropic.claude-3-sonnet-20240229-v1:0",
        maxTokens: 1000,
        temperature: 0.3,
        region: "us-east-1",
        costPerToken: 0.003, // USD per 1K tokens
    },
};
exports.default = {
    SUPPORTED_LANGUAGES: exports.SUPPORTED_LANGUAGES,
    SYMPTOM_SEVERITIES: exports.SYMPTOM_SEVERITIES,
    RECOMMENDED_ACTIONS: exports.RECOMMENDED_ACTIONS,
    QATAR_LOCATIONS: exports.QATAR_LOCATIONS,
    QATAR_EMERGENCY_CONTACTS: exports.QATAR_EMERGENCY_CONTACTS,
    AI_MODEL_CONFIGS: exports.AI_MODEL_CONFIGS,
};
