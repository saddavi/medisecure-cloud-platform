/**
 * AI Prompt Templates for MediSecure Healthcare Platform
 * Supports Arabic and English with cultural healthcare considerations
 */
export interface PromptContext {
    symptoms: string;
    language: "en" | "ar";
    patientAge?: number;
    patientGender?: "male" | "female";
    medicalHistory?: string[];
    culturalContext?: "qatar" | "gulf" | "general";
}
export declare class PromptTemplates {
    /**
     * Main symptom analysis prompt with cultural considerations
     */
    static getSymptomAnalysisPrompt(context: PromptContext): string;
    /**
     * Anonymous public symptom checker prompt (for non-logged-in users)
     */
    static getAnonymousSymptomPrompt(symptoms: string, language: "en" | "ar"): string;
    /**
     * Follow-up question generation prompt
     */
    static getFollowUpPrompt(initialSymptoms: string, language: "en" | "ar"): string;
    /**
     * Emergency assessment prompt for high-severity symptoms
     */
    static getEmergencyAssessmentPrompt(symptoms: string, language: "en" | "ar"): string;
    /**
     * Build patient context information
     */
    private static buildContextInfo;
    /**
     * Get cultural considerations for the region
     */
    private static getCulturalConsiderations;
}
export default PromptTemplates;
