/**
 * AWS Bedrock Client for AI-powered healthcare analysis
 * Optimized for Qatar's healthcare market with Arabic support
 */
export interface BedrockConfig {
    region: string;
    maxTokens: number;
    temperature: number;
}
export interface AIResponse {
    analysis: string;
    severity: "Low" | "Medium" | "High" | "Emergency";
    urgencyScore: number;
    recommendations: {
        action: "self-care" | "appointment" | "urgent-care" | "emergency";
        timeframe: string;
        specialist?: string;
    };
    followUpQuestions: string[];
    language: "en" | "ar";
}
export declare class BedrockClient {
    private client;
    private config;
    constructor(region?: string);
    /**
     * Get the best available model for symptom analysis
     * Falls back to Titan if Claude is not accessible
     */
    private getBestAvailableModel;
    /**
     * Analyze symptoms using Claude 3 Haiku model
     * @param symptoms - Patient symptoms description
     * @param language - Response language (en/ar)
     * @param patientContext - Optional patient context for personalization
     */
    analyzeSymptoms(symptoms: string, language?: "en" | "ar", patientContext?: {
        age?: number;
        gender?: string;
        medicalHistory?: string[];
    }): Promise<AIResponse>;
    /**
     * Build comprehensive prompt for symptom analysis
     */
    private buildSymptomPrompt;
    /**
     * Parse AI response into structured format
     */
    private parseAIResponse;
}
export default BedrockClient;
