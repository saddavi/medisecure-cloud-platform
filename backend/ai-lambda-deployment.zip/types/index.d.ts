import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from "aws-lambda";
export type LambdaHandler = (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
export interface UserRegistrationRequest {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phoneNumber?: string;
    dateOfBirth?: string;
    acceptedTerms: boolean;
    acceptedPrivacyPolicy: boolean;
}
export interface UserRegistrationResponse {
    success: boolean;
    message: string;
    userId?: string;
    verificationRequired?: boolean;
}
export interface UserLoginRequest {
    email: string;
    password: string;
}
export interface UserLoginResponse {
    success: boolean;
    message: string;
    accessToken?: string;
    refreshToken?: string;
    idToken?: string;
    expiresIn?: number;
}
export interface PatientProfile {
    PK: string;
    SK: string;
    GSI1PK: string;
    GSI1SK: string;
    entityType: "USER";
    userType: "PATIENT" | "PROVIDER";
    patientId: string;
    cognitoUserId: string;
    personalInfo: {
        firstName: string;
        lastName: string;
        email: string;
        phoneNumber?: string;
        dateOfBirth?: string;
        gender?: "M" | "F" | "O";
        address?: {
            street: string;
            city: string;
            state: string;
            country: string;
            postalCode: string;
        };
    };
    medicalInfo: {
        bloodType?: string;
        allergies?: string[];
        emergencyContact?: {
            name: string;
            relationship: string;
            phoneNumber: string;
        };
        insuranceProvider?: string;
        insuranceNumber?: string;
        medicalConditions?: string[];
        medications?: string[];
    };
    preferences: {
        language: string;
        timezone: string;
        communicationMethod: "email" | "sms" | "both";
    };
    createdAt: string;
    updatedAt: string;
    status: "ACTIVE" | "INACTIVE" | "SUSPENDED";
}
export interface PatientCreateRequest {
    cognitoUserId?: string;
    personalInfo: {
        firstName: string;
        lastName: string;
        email: string;
        phoneNumber?: string;
        dateOfBirth?: string;
        gender?: "M" | "F" | "O";
        address?: {
            street: string;
            city: string;
            state: string;
            country: string;
            postalCode: string;
        };
    };
    medicalInfo?: {
        bloodType?: string;
        allergies?: string[];
        emergencyContact?: {
            name: string;
            relationship: string;
            phoneNumber: string;
        };
        insuranceProvider?: string;
        insuranceNumber?: string;
    };
    preferences?: {
        language?: string;
        timezone?: string;
        communicationMethod?: "email" | "sms" | "both";
    };
}
export interface PatientUpdateRequest {
    personalInfo?: Partial<PatientCreateRequest["personalInfo"]>;
    medicalInfo?: Partial<PatientCreateRequest["medicalInfo"]>;
    preferences?: Partial<PatientCreateRequest["preferences"]>;
    status?: "ACTIVE" | "INACTIVE" | "SUSPENDED";
}
export interface MedicalRecord {
    PK: string;
    SK: string;
    GSI1PK: string;
    GSI1SK: string;
    GSI2PK: string;
    GSI2SK: string;
    entityType: "RECORD";
    recordType: "CONSULTATION" | "DIAGNOSTIC" | "TREATMENT" | "FOLLOW_UP" | "EMERGENCY";
    recordId: string;
    patientId: string;
    providerId: string;
    appointmentId?: string;
    visitInfo: {
        date: string;
        type: "REGULAR_CHECKUP" | "FOLLOW_UP" | "EMERGENCY" | "CONSULTATION" | "PROCEDURE";
        duration: number;
        location: string;
    };
    clinicalData: {
        chiefComplaint?: string;
        symptoms?: string[];
        vitalSigns?: {
            bloodPressure?: string;
            heartRate?: number;
            temperature?: number;
            weight?: number;
            height?: number;
            respiratoryRate?: number;
            oxygenSaturation?: number;
        };
        diagnosis?: Array<{
            code: string;
            description: string;
            severity?: "MILD" | "MODERATE" | "SEVERE";
        }>;
        treatment?: {
            prescription?: Array<{
                medication: string;
                dosage: string;
                frequency: string;
                duration: string;
            }>;
            procedures?: Array<{
                name: string;
                description: string;
                date: string;
            }>;
            recommendations?: string[];
        };
    };
    followUp: {
        required: boolean;
        timeframe?: string;
        notes?: string;
    };
    attachments: Array<{
        documentId: string;
        type: "ECG_REPORT" | "LAB_RESULT" | "X_RAY" | "MRI" | "CT_SCAN" | "PRESCRIPTION" | "OTHER";
        s3Key: string;
    }>;
    createdAt: string;
    updatedAt: string;
    status: "DRAFT" | "COMPLETED" | "REVIEWED" | "ARCHIVED";
}
export interface MedicalRecordCreateRequest {
    recordType: MedicalRecord["recordType"];
    providerId: string;
    appointmentId?: string;
    visitInfo: {
        date?: string;
        type: MedicalRecord["visitInfo"]["type"];
        duration?: number;
        location: string;
    };
    clinicalData: MedicalRecord["clinicalData"];
    followUp?: MedicalRecord["followUp"];
    attachments?: MedicalRecord["attachments"];
}
export interface MedicalRecordUpdateRequest {
    clinicalData?: Partial<MedicalRecord["clinicalData"]>;
    followUp?: Partial<MedicalRecord["followUp"]>;
    attachments?: MedicalRecord["attachments"];
    status?: MedicalRecord["status"];
}
export interface Appointment {
    PK: string;
    SK: string;
    GSI1PK: string;
    GSI1SK: string;
    GSI2PK: string;
    GSI2SK: string;
    entityType: "APPOINTMENT";
    appointmentId: string;
    patientId: string;
    providerId: string;
    schedulingInfo: {
        appointmentDate: string;
        duration: number;
        type: "CONSULTATION" | "FOLLOW_UP" | "PROCEDURE" | "EMERGENCY";
        location: string;
        mode: "IN_PERSON" | "TELEMEDICINE" | "PHONE";
    };
    reason: string;
    preparation?: string[];
    reminder: {
        sent: boolean;
        scheduledFor: string;
    };
    payment: {
        fee: number;
        currency: string;
        status: "PENDING" | "PAID" | "CANCELLED";
        method: "CASH" | "CARD" | "INSURANCE" | "BANK_TRANSFER";
    };
    createdAt: string;
    updatedAt: string;
    status: "SCHEDULED" | "CONFIRMED" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED" | "NO_SHOW";
}
export interface MedicalDocument {
    PK: string;
    SK: string;
    GSI1PK: string;
    GSI1SK: string;
    entityType: "DOCUMENT";
    documentId: string;
    patientId: string;
    providerId: string;
    recordId?: string;
    documentInfo: {
        type: "ECG_REPORT" | "LAB_RESULT" | "X_RAY" | "MRI" | "CT_SCAN" | "PRESCRIPTION" | "INSURANCE" | "OTHER";
        title: string;
        description: string;
        category: "DIAGNOSTIC_REPORT" | "PRESCRIPTION" | "INSURANCE_DOC" | "CONSENT_FORM" | "OTHER";
    };
    fileInfo: {
        s3Bucket: string;
        s3Key: string;
        fileName: string;
        fileSize: number;
        mimeType: string;
        checksum: string;
    };
    security: {
        encryptionStatus: "ENCRYPTED" | "PENDING" | "FAILED";
        accessLevel: "PATIENT_ONLY" | "PATIENT_PROVIDER_ONLY" | "FULL_ACCESS";
        retentionPeriod: "1_YEAR" | "7_YEARS" | "INDEFINITE";
    };
    createdAt: string;
    updatedAt: string;
    status: "ACTIVE" | "ARCHIVED" | "DELETED";
}
export interface EmergencyContact {
    name: string;
    relationship: string;
    phoneNumber: string;
    email?: string;
}
export interface ApiResponse<T = any> {
    statusCode: number;
    success: boolean;
    message: string;
    data?: T;
    error?: string;
    timestamp: string;
    requestId: string;
}
export declare enum ErrorCodes {
    VALIDATION_ERROR = "VALIDATION_ERROR",
    AUTHENTICATION_ERROR = "AUTHENTICATION_ERROR",
    AUTHORIZATION_ERROR = "AUTHORIZATION_ERROR",
    USER_EXISTS = "USER_EXISTS",
    USER_NOT_FOUND = "USER_NOT_FOUND",
    INVALID_CREDENTIALS = "INVALID_CREDENTIALS",
    EMAIL_NOT_VERIFIED = "EMAIL_NOT_VERIFIED",
    INTERNAL_ERROR = "INTERNAL_ERROR",
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED"
}
export interface MediSecureError {
    code: ErrorCodes;
    message: string;
    details?: any;
    timestamp: string;
}
export interface CognitoConfig {
    userPoolId: string;
    clientId: string;
    clientSecret?: string;
    region: string;
}
export interface AppConfig {
    cognito: CognitoConfig;
    environment: "development" | "staging" | "production";
    region: string;
    logLevel: "debug" | "info" | "warn" | "error";
}
export interface ValidationResult {
    isValid: boolean;
    errors: string[];
}
