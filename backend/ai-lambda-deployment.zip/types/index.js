"use strict";
// MediSecure Cloud Platform - Type Definitions
// Healthcare-grade type safety for patient data protection
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorCodes = void 0;
// ============= Error Types =============
var ErrorCodes;
(function (ErrorCodes) {
    ErrorCodes["VALIDATION_ERROR"] = "VALIDATION_ERROR";
    ErrorCodes["AUTHENTICATION_ERROR"] = "AUTHENTICATION_ERROR";
    ErrorCodes["AUTHORIZATION_ERROR"] = "AUTHORIZATION_ERROR";
    ErrorCodes["USER_EXISTS"] = "USER_EXISTS";
    ErrorCodes["USER_NOT_FOUND"] = "USER_NOT_FOUND";
    ErrorCodes["INVALID_CREDENTIALS"] = "INVALID_CREDENTIALS";
    ErrorCodes["EMAIL_NOT_VERIFIED"] = "EMAIL_NOT_VERIFIED";
    ErrorCodes["INTERNAL_ERROR"] = "INTERNAL_ERROR";
    ErrorCodes["RATE_LIMIT_EXCEEDED"] = "RATE_LIMIT_EXCEEDED";
})(ErrorCodes || (exports.ErrorCodes = ErrorCodes = {}));
