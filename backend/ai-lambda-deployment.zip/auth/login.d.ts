import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from "aws-lambda";
/**
 * AWS Lambda handler for user authentication
 *
 * This function handles user login for the MediSecure healthcare platform.
 * It validates credentials against AWS Cognito and returns JWT tokens for successful authentication.
 *
 * Security Features:
 * - Input validation and sanitization
 * - Rate limiting through Cognito
 * - Secure JWT token handling
 * - Comprehensive audit logging
 * - Protection against brute force attacks
 *
 * @param event - API Gateway proxy event containing login credentials
 * @param context - Lambda execution context
 * @returns Promise<APIGatewayProxyResult> - Authentication response with tokens
 */
export declare const handler: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
/**
 * Utility function to validate JWT tokens (for use in other Lambda functions)
 * @param token - JWT token to validate
 * @returns Promise<boolean> - Token validity
 */
export declare const validateToken: (token: string) => Promise<boolean>;
