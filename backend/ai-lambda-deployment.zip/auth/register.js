"use strict";
// MediSecure Cloud Platform - User Registration Lambda Function
// Healthcare-grade user registration with Cognito integration
Object.defineProperty(exports, "__esModule", { value: true });
exports.healthCheck = exports.handler = void 0;
const cognito_1 = require("../utils/cognito");
const validation_1 = require("../utils/validation");
const response_1 = require("../utils/response");
// ============= Environment Validation =============
// Ensure all required environment variables are set on Lambda startup
const REQUIRED_ENV_VARS = [
    "COGNITO_USER_POOL_ID",
    "COGNITO_CLIENT_ID",
    "AWS_REGION",
];
try {
    (0, response_1.validateEnvironment)(REQUIRED_ENV_VARS);
    (0, response_1.log)(response_1.LogLevel.INFO, "Environment validation passed");
}
catch (error) {
    (0, response_1.log)(response_1.LogLevel.ERROR, "Environment validation failed", {
        error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
}
// ============= Initialize Services =============
const cognitoService = new cognito_1.CognitoService();
// ============= Lambda Handler =============
/**
 * AWS Lambda handler for user registration
 *
 * This function handles user registration for the MediSecure healthcare platform.
 * It validates input data, creates a new user in AWS Cognito, and returns appropriate responses.
 *
 * Security Features:
 * - Input validation and sanitization
 * - Healthcare-grade password requirements
 * - Qatar-specific data validation
 * - Structured error handling and logging
 * - CORS support for web frontend integration
 *
 * @param event - API Gateway proxy event containing user registration data
 * @param context - Lambda execution context
 * @returns Promise<APIGatewayProxyResult> - Standardized API response
 */
const handler = async (event, context) => {
    // Generate request ID for tracing and debugging
    const requestId = context.awsRequestId;
    (0, response_1.log)(response_1.LogLevel.INFO, "User registration request started", {
        requestId,
        httpMethod: event.httpMethod,
        sourceIp: event.requestContext.identity.sourceIp,
        userAgent: event.headers["User-Agent"],
    });
    try {
        // ============= Handle CORS Preflight =============
        if (event.httpMethod === "OPTIONS") {
            return {
                statusCode: 200,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                    "Access-Control-Allow-Methods": "OPTIONS,POST",
                },
                body: "",
            };
        }
        // ============= Validate HTTP Method =============
        if (event.httpMethod !== "POST") {
            (0, response_1.log)(response_1.LogLevel.WARN, "Invalid HTTP method", {
                requestId,
                method: event.httpMethod,
            });
            return (0, response_1.badRequestResponse)("Only POST method is allowed for user registration");
        }
        // ============= Parse Request Body =============
        const requestData = (0, response_1.parseRequestBody)(event.body);
        if (!requestData) {
            (0, response_1.log)(response_1.LogLevel.WARN, "Invalid request body", { requestId });
            return (0, response_1.badRequestResponse)("Invalid JSON in request body");
        }
        (0, response_1.log)(response_1.LogLevel.DEBUG, "Request data parsed", {
            requestId,
            email: requestData.email,
            firstName: requestData.firstName,
            lastName: requestData.lastName,
            hasPhoneNumber: !!requestData.phoneNumber,
            hasDateOfBirth: !!requestData.dateOfBirth,
        });
        // ============= Validate Input Data =============
        // Standard validation (password strength, email format, etc.)
        const standardValidation = (0, validation_1.validateRegistration)(requestData);
        if (!standardValidation.isValid) {
            (0, response_1.log)(response_1.LogLevel.WARN, "Standard validation failed", {
                requestId,
                errors: standardValidation.errors,
            });
            return (0, response_1.badRequestResponse)("Validation failed", standardValidation.errors);
        }
        // Qatar-specific validation (if applicable)
        const qatarValidation = (0, validation_1.validateQatarSpecific)(requestData);
        if (!qatarValidation.isValid) {
            (0, response_1.log)(response_1.LogLevel.WARN, "Qatar-specific validation failed", {
                requestId,
                errors: qatarValidation.errors,
            });
            return (0, response_1.badRequestResponse)("Validation failed", qatarValidation.errors);
        }
        (0, response_1.log)(response_1.LogLevel.INFO, "Input validation passed", { requestId });
        // ============= Register User with Cognito =============
        const registrationResult = await cognitoService.registerUser(requestData);
        if (registrationResult.success) {
            (0, response_1.log)(response_1.LogLevel.INFO, "User registration completed successfully", {
                requestId,
                userId: registrationResult.userId,
                email: requestData.email,
                verificationRequired: registrationResult.verificationRequired,
            });
            // Return success response with user data (excluding sensitive information)
            return (0, response_1.successResponse)({
                userId: registrationResult.userId,
                email: requestData.email,
                firstName: requestData.firstName,
                lastName: requestData.lastName,
                verificationRequired: registrationResult.verificationRequired,
                message: registrationResult.message,
            }, "User registration successful");
        }
        else {
            (0, response_1.log)(response_1.LogLevel.WARN, "User registration failed", {
                requestId,
                email: requestData.email,
                reason: registrationResult.message,
            });
            // Return appropriate error response based on the registration failure
            if (registrationResult.message.includes("already exists")) {
                return (0, response_1.badRequestResponse)(registrationResult.message);
            }
            else if (registrationResult.message.includes("Password")) {
                return (0, response_1.badRequestResponse)(registrationResult.message);
            }
            else {
                return (0, response_1.internalServerErrorResponse)(registrationResult.message);
            }
        }
    }
    catch (error) {
        // ============= Handle Unexpected Errors =============
        (0, response_1.log)(response_1.LogLevel.ERROR, "Unexpected error in user registration", {
            requestId,
            error: error instanceof Error ? error.message : "Unknown error",
            stack: error instanceof Error ? error.stack : undefined,
        });
        return (0, response_1.internalServerErrorResponse)("An unexpected error occurred during registration. Please try again later.", error instanceof Error ? error.message : "Unknown error");
    }
    finally {
        (0, response_1.log)(response_1.LogLevel.INFO, "User registration request completed", {
            requestId,
            duration: Date.now() -
                (context.getRemainingTimeInMillis
                    ? context.getRemainingTimeInMillis() -
                        context.getRemainingTimeInMillis()
                    : 0),
        });
    }
};
exports.handler = handler;
// ============= Health Check Export =============
// Optional: Export a simple health check function for monitoring
const healthCheck = async () => {
    return {
        status: "healthy",
        timestamp: new Date().toISOString(),
    };
};
exports.healthCheck = healthCheck;
