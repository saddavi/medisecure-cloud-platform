"use strict";
// MediSecure Cloud Platform - User Login Lambda Function
// Healthcare-grade user authentication with JWT token management
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateToken = exports.handler = void 0;
const cognito_1 = require("../utils/cognito");
const validation_1 = require("../utils/validation");
const response_1 = require("../utils/response");
// ============= Environment Validation =============
const REQUIRED_ENV_VARS = [
    "COGNITO_USER_POOL_ID",
    "COGNITO_CLIENT_ID",
    "AWS_REGION",
];
try {
    (0, response_1.validateEnvironment)(REQUIRED_ENV_VARS);
    (0, response_1.log)(response_1.LogLevel.INFO, "Environment validation passed for login handler");
}
catch (error) {
    (0, response_1.log)(response_1.LogLevel.ERROR, "Environment validation failed for login handler", {
        error: error instanceof Error ? error.message : "Unknown error",
    });
    throw error;
}
// ============= Initialize Services =============
const cognitoService = new cognito_1.CognitoService();
// ============= Lambda Handler =============
/**
 * AWS Lambda handler for user authentication
 *
 * This function handles user login for the MediSecure healthcare platform.
 * It validates credentials against AWS Cognito and returns JWT tokens for successful authentication.
 *
 * Security Features:
 * - Input validation and sanitization
 * - Rate limiting through Cognito
 * - Secure JWT token handling
 * - Comprehensive audit logging
 * - Protection against brute force attacks
 *
 * @param event - API Gateway proxy event containing login credentials
 * @param context - Lambda execution context
 * @returns Promise<APIGatewayProxyResult> - Authentication response with tokens
 */
const handler = async (event, context) => {
    const requestId = context.awsRequestId;
    (0, response_1.log)(response_1.LogLevel.INFO, "User login request started", {
        requestId,
        httpMethod: event.httpMethod,
        sourceIp: event.requestContext.identity.sourceIp,
        userAgent: event.headers["User-Agent"],
    });
    try {
        // ============= Handle CORS Preflight =============
        if (event.httpMethod === "OPTIONS") {
            return {
                statusCode: 200,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                    "Access-Control-Allow-Methods": "OPTIONS,POST",
                },
                body: "",
            };
        }
        // ============= Validate HTTP Method =============
        if (event.httpMethod !== "POST") {
            (0, response_1.log)(response_1.LogLevel.WARN, "Invalid HTTP method for login", {
                requestId,
                method: event.httpMethod,
            });
            return (0, response_1.badRequestResponse)("Only POST method is allowed for user login");
        }
        // ============= Parse Request Body =============
        const loginData = (0, response_1.parseRequestBody)(event.body);
        if (!loginData) {
            (0, response_1.log)(response_1.LogLevel.WARN, "Invalid request body for login", { requestId });
            return (0, response_1.badRequestResponse)("Invalid JSON in request body");
        }
        // Log login attempt (without password for security)
        (0, response_1.log)(response_1.LogLevel.INFO, "Login attempt", {
            requestId,
            email: loginData.email,
            sourceIp: event.requestContext.identity.sourceIp,
        });
        // ============= Validate Input Data =============
        const validation = (0, validation_1.validateLogin)(loginData);
        if (!validation.isValid) {
            (0, response_1.log)(response_1.LogLevel.WARN, "Login validation failed", {
                requestId,
                email: loginData.email,
                errors: validation.errors,
            });
            return (0, response_1.badRequestResponse)("Validation failed", validation.errors);
        }
        (0, response_1.log)(response_1.LogLevel.DEBUG, "Login validation passed", {
            requestId,
            email: loginData.email,
        });
        // ============= Authenticate User with Cognito =============
        const authResult = await cognitoService.authenticateUser(loginData);
        if (authResult.success) {
            (0, response_1.log)(response_1.LogLevel.INFO, "User authentication successful", {
                requestId,
                email: loginData.email,
                hasAccessToken: !!authResult.accessToken,
                hasRefreshToken: !!authResult.refreshToken,
                hasIdToken: !!authResult.idToken,
            });
            // Return success response with tokens (but log token presence only, not actual tokens)
            return (0, response_1.successResponse)({
                accessToken: authResult.accessToken,
                refreshToken: authResult.refreshToken,
                idToken: authResult.idToken,
                expiresIn: authResult.expiresIn,
                tokenType: "Bearer",
                message: authResult.message,
            }, "Authentication successful");
        }
        else {
            (0, response_1.log)(response_1.LogLevel.WARN, "User authentication failed", {
                requestId,
                email: loginData.email,
                reason: authResult.message,
            });
            // Return appropriate error response based on the authentication failure
            if (authResult.message.includes("verify your email")) {
                return (0, response_1.badRequestResponse)(authResult.message);
            }
            else if (authResult.message.includes("Invalid email or password") ||
                authResult.message.includes("No account found")) {
                return (0, response_1.unauthorizedResponse)(authResult.message);
            }
            else if (authResult.message.includes("Too many")) {
                return {
                    statusCode: 429,
                    headers: {
                        "Content-Type": "application/json",
                        "Access-Control-Allow-Origin": "*",
                        "Retry-After": "300", // 5 minutes
                    },
                    body: JSON.stringify({
                        success: false,
                        message: authResult.message,
                        timestamp: new Date().toISOString(),
                        requestId,
                    }),
                };
            }
            else {
                return (0, response_1.unauthorizedResponse)(authResult.message);
            }
        }
    }
    catch (error) {
        // ============= Handle Unexpected Errors =============
        (0, response_1.log)(response_1.LogLevel.ERROR, "Unexpected error in user login", {
            requestId,
            error: error instanceof Error ? error.message : "Unknown error",
            stack: error instanceof Error ? error.stack : undefined,
        });
        return (0, response_1.internalServerErrorResponse)("An unexpected error occurred during authentication. Please try again later.", error instanceof Error ? error.message : "Unknown error");
    }
    finally {
        (0, response_1.log)(response_1.LogLevel.INFO, "User login request completed", {
            requestId,
            duration: Date.now() -
                (context.getRemainingTimeInMillis
                    ? context.getRemainingTimeInMillis() -
                        context.getRemainingTimeInMillis()
                    : 0),
        });
    }
};
exports.handler = handler;
// ============= Token Validation Export =============
/**
 * Utility function to validate JWT tokens (for use in other Lambda functions)
 * @param token - JWT token to validate
 * @returns Promise<boolean> - Token validity
 */
const validateToken = async (token) => {
    try {
        // In a production environment, you would verify the JWT signature
        // against Cognito's public keys. For now, we'll do basic validation.
        if (!token || token.split(".").length !== 3) {
            return false;
        }
        // Decode the payload (without verification - for demonstration)
        const payload = JSON.parse(Buffer.from(token.split(".")[1], "base64").toString());
        // Check if token is expired
        const now = Math.floor(Date.now() / 1000);
        if (payload.exp && payload.exp < now) {
            return false;
        }
        // Check if token is from our user pool
        if (!payload.iss ||
            !payload.iss.includes(process.env.COGNITO_USER_POOL_ID)) {
            return false;
        }
        return true;
    }
    catch (error) {
        (0, response_1.log)(response_1.LogLevel.ERROR, "Token validation error", {
            error: error instanceof Error ? error.message : "Unknown error",
        });
        return false;
    }
};
exports.validateToken = validateToken;
