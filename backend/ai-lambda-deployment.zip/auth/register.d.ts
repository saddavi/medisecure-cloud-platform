import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from "aws-lambda";
/**
 * AWS Lambda handler for user registration
 *
 * This function handles user registration for the MediSecure healthcare platform.
 * It validates input data, creates a new user in AWS Cognito, and returns appropriate responses.
 *
 * Security Features:
 * - Input validation and sanitization
 * - Healthcare-grade password requirements
 * - Qatar-specific data validation
 * - Structured error handling and logging
 * - CORS support for web frontend integration
 *
 * @param event - API Gateway proxy event containing user registration data
 * @param context - Lambda execution context
 * @returns Promise<APIGatewayProxyResult> - Standardized API response
 */
export declare const handler: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
export declare const healthCheck: () => Promise<{
    status: string;
    timestamp: string;
}>;
